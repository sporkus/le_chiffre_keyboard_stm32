G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,7.0.11+1*
G04 #@! TF.CreationDate,2026-05-02T23:31:53+00:00*
G04 #@! TF.ProjectId,LeChiffre_Plate,4c654368-6966-4667-9265-5f506c617465,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 7.0.11+1) date 2026-05-02 23:31:53*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
