G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,7.0.11+1*
G04 #@! TF.CreationDate,2026-05-02T23:32:10+00:00*
G04 #@! TF.ProjectId,plate_alps_mx,706c6174-655f-4616-9c70-735f6d782e6b,v0.1*
G04 #@! TF.SameCoordinates,PX8bd8a70PY50733a9*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 7.0.11+1) date 2026-05-02 23:32:10*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
